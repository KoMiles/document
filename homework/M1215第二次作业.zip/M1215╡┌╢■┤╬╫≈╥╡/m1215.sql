-- phpMyAdmin SQL Dump
-- version 3.4.10.1
-- http://www.phpmyadmin.net
--
-- 主机: localhost
-- 生成日期: 2014 年 10 月 07 日 14:38
-- 服务器版本: 5.5.20
-- PHP 版本: 5.3.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `metinfo`
--

-- --------------------------------------------------------

--
-- 表的结构 `met_applist`
--

CREATE TABLE IF NOT EXISTS `met_applist` (
  `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'ID主键',
  `no` int(11) NOT NULL COMMENT '应用编号',
  `ver` varchar(50) NOT NULL COMMENT '应用版本',
  `m_name` varchar(50) NOT NULL COMMENT '应用系统名称',
  `m_class` varchar(50) NOT NULL COMMENT '默认控制器',
  `m_action` varchar(50) NOT NULL COMMENT '默认事件',
  `appname` varchar(50) NOT NULL COMMENT '应用名称',
  `info` text NOT NULL COMMENT '应用描述',
  `addtime` int(11) NOT NULL COMMENT '发布时间',
  `updateime` int(11) NOT NULL COMMENT '最近更新时间',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `met_applist`
--

INSERT INTO `met_applist` (`id`, `no`, `ver`, `m_name`, `m_class`, `m_action`, `appname`, `info`, `addtime`, `updateime`) VALUES
(1, 1001, '1.0', 'ceshi', 'adminceshi', 'doindex', '应用测试', '应用测试111', 0, 0),
(3, 1215, '1.0', 'm1215', 'm1215', 'doindex', 'm1215', '序号1215制作的应用', 0, 0);

-- --------------------------------------------------------

--
-- 表的结构 `met_app_plugin`
--

CREATE TABLE IF NOT EXISTS `met_app_plugin` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no_order` int(11) NOT NULL COMMENT '排序',
  `no` int(11) NOT NULL COMMENT '应用编号',
  `m_name` varchar(255) NOT NULL COMMENT '应用名称',
  `m_action` varchar(255) NOT NULL COMMENT '事件',
  `effect` tinyint(1) NOT NULL COMMENT '是否生效',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `met_app_plugin`
--

INSERT INTO `met_app_plugin` (`id`, `no_order`, `no`, `m_name`, `m_action`, `effect`) VALUES
(1, 1, 1215, 'm1215', 'doweb', 1);

-- --------------------------------------------------------

--
-- 表的结构 `met_ifcolumn`
--

CREATE TABLE IF NOT EXISTS `met_ifcolumn` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `no` int(11) NOT NULL COMMENT '应用编号',
  `name` varchar(50) NOT NULL COMMENT '应用系统名称',
  `appname` varchar(50) NOT NULL COMMENT '应用名称',
  `addfile` tinyint(1) NOT NULL DEFAULT '1' COMMENT '添加栏目是否是否生成文件',
  `memberleft` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否添加在会员侧导航',
  `uniqueness` tinyint(1) NOT NULL DEFAULT '0' COMMENT '是否只允许添加一个',
  `fixed_name` varchar(50) DEFAULT NULL COMMENT '是否固定栏目的文件夹名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- 转存表中的数据 `met_ifcolumn`
--

INSERT INTO `met_ifcolumn` (`id`, `no`, `name`, `appname`, `addfile`, `memberleft`, `uniqueness`, `fixed_name`) VALUES
(1, 1215, 'm1215', '本地应用开发', 1, 1, 1, NULL);

-- --------------------------------------------------------

--
-- 表的结构 `met_ifcolumn_addfile`
--

CREATE TABLE IF NOT EXISTS `met_ifcolumn_addfile` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `no` int(11) NOT NULL COMMENT '应用编号',
  `filename` varchar(255) NOT NULL COMMENT '文件名称',
  `m_name` varchar(255) NOT NULL COMMENT '应用系统名称',
  `m_module` varchar(255) NOT NULL COMMENT '模块所属',
  `m_class` varchar(255) NOT NULL COMMENT '控制器名',
  `m_action` varchar(255) NOT NULL COMMENT '事件名称',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

--
-- 转存表中的数据 `met_ifcolumn_addfile`
--

INSERT INTO `met_ifcolumn_addfile` (`id`, `no`, `filename`, `m_name`, `m_module`, `m_class`, `m_action`) VALUES
(1, 1215, 'index.php', 'm1215', 'web', 'm1215', 'doindex'),
(3, 1215, 'save.php', 'm1215', 'web', 'm1215', 'dosave');

-- --------------------------------------------------------

--
-- 表的结构 `met_ifmember_left`
--

CREATE TABLE IF NOT EXISTS `met_ifmember_left` (
  `id` int(11) unsigned NOT NULL AUTO_INCREMENT,
  `no` int(11) NOT NULL COMMENT '应用编号',
  `columnid` int(11) NOT NULL COMMENT '文件名称',
  `title` varchar(50) NOT NULL COMMENT '链接名称',
  `foldername` varchar(255) NOT NULL COMMENT '链接文件夹',
  `filename` varchar(255) NOT NULL COMMENT '链接文件',
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- 转存表中的数据 `met_ifmember_left`
--

INSERT INTO `met_ifmember_left` (`id`, `no`, `columnid`, `title`, `foldername`, `filename`) VALUES
(4, 1215, 101, '本地应用开发', 'doindex', 'index.php');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
