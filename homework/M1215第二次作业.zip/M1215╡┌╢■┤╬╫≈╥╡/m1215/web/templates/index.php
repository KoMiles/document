<!--<?php

defined('IN_MET') or exit('No permission');//保持入口文件，每个应用模板都要添加
echo <<<EOT
-->




<a>html代码{$test}</a>




<!--
EOT;
?>