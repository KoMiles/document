<?php
/**
 *description:save.php
 *date 2014-10-07 21:46:00
 *author komiles<komiles@163.com>
 **/

	define('M_NAME', 'm1215');
	define('M_MODULE', 'web');
	define('M_CLASS', 'm1215');
	define('M_ACTION', 'dosave');
	require_once '../app/app/entrance.php';//因为入口是app所以不要赋值M_TYPE。
?>

